create procedure paysSelectOne(IN asIdPays char(4))
BEGIN
  SELECT *
  FROM pays
  WHERE id_pays= asIdPays;
END;

