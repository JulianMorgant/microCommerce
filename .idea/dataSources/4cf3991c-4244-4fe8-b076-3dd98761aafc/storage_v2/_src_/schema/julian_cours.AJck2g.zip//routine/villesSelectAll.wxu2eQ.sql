create procedure villesSelectAll()
BEGIN
  SELECT * FROM villes;
END;

