create procedure clientsDUneVille(IN asCp char(5))
BEGIN
  SELECT *
  FROM clients
  WHERE cp = asCP;
END;

