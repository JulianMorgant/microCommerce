create procedure villesSelectOne(IN asCp char(5))
BEGIN
  SELECT * FROM villes WHERE cp = asCp;
END;

