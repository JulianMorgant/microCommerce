create procedure paysInsert(IN asIdPays char(4), IN asNomPays varchar(50))
BEGIN
INSERT INTO pays(id_pays, nom_pays) VALUES(asIdPays, asNomPays);
END;

