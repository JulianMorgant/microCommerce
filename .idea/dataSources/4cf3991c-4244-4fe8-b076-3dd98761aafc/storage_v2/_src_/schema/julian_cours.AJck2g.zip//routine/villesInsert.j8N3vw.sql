create procedure villesInsert(IN asCp char(5), IN asVille varchar(50), IN asSite varchar(50), IN asPhoto varchar(50),
                              IN asIdPays char(4))
BEGIN
   INSERT INTO villes(cp, nom_ville, site, photo, id_pays) VALUES(asCp, asVille, asSite, asPhoto, asIdPays);
END;

