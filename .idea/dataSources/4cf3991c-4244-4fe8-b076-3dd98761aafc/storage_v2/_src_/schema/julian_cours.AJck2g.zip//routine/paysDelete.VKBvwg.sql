create procedure paysDelete(IN asPays varchar(5))
BEGIN
	DELETE FROM pays WHERE asPays = id_pays;
END;

