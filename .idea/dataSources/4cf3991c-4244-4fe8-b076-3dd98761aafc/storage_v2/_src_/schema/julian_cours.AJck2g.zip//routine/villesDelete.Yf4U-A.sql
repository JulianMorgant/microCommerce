create procedure villesDelete(IN asCp char(5))
BEGIN
   DELETE FROM villes WHERE cp = asCp;
END;

