create procedure villesUpdate(IN asVille varchar(50), IN asSite varchar(50), IN asPhoto varchar(50),
                              IN asIdPays char(4), IN asCp char(5))
BEGIN
   UPDATE villes SET nom_ville = asVille, site = asSite, photo = asPhoto WHERE cp = asCp;
END;

