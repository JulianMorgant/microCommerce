create procedure paysSelect()
BEGIN
   SELECT * 
   FROM pays;
END;

